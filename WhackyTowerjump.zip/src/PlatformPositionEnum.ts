namespace PrimaAbgabeLW {
    export enum PlatPos {
        lt, 
        mt, 
        rt,
        lm,     
        rm,
        lb, 
        mb, 
        rb
    }
}